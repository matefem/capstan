<?php

namespace WPStaging\Framework\Filesystem\Scanning;

class ScanConst
{
    /**
     * separator to separate directories
     * @var string
     */
    const DIRECTORIES_SEPARATOR = ',';
}
