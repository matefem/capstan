<?php

namespace WPStaging\Framework\Filesystem;

class MissingFileException extends FilesystemExceptions
{

}
