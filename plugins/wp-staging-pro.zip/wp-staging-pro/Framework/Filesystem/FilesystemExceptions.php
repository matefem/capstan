<?php

namespace WPStaging\Framework\Filesystem;

class FilesystemExceptions extends \Exception
{

}
