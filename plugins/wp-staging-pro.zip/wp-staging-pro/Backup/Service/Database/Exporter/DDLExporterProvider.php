<?php
namespace WPStaging\Backup\Service\Database\Exporter;
class DDLExporterProvider extends AbstractExporterProvider
{
}
