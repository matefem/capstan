<?php

namespace WPStaging\Backup\Service;

/**
 * Don't enforce any methods, just a marker interface for dependency injection
 */
interface ServiceInterface
{
}
