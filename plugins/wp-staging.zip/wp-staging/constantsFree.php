<?php

// WP STAGING version number
if (!defined('WPSTG_VERSION')) {
    define('WPSTG_VERSION', '3.8.4');
}

// Compatible up to WordPress Version
if (!defined('WPSTG_COMPATIBLE')) {
    define('WPSTG_COMPATIBLE', '6.6.1');
}
