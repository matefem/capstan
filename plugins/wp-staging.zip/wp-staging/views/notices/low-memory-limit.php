<div class="notice notice-warning">
        <?php echo sprintf(__('It\'s recommended to increase the memory limit to 256M or more! If cloning/pushing <strong>fails</strong> <a href="%s" target="_blank">increase the memory limit</a>.', 'wp-staging'), 'https://wp-staging.com/docs/php-fatal-error-allowed-memory-size-of-134217728-bytes-exhausted/'); ?> 
</div>