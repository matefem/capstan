<?php
namespace WPStaging\Backup\Service\Database\Exporter;
class RowsExporterProvider extends AbstractExporterProvider
{
}
