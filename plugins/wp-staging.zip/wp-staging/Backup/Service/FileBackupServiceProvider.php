<?php

namespace WPStaging\Backup\Service;

/**
 * Class FileBackupServiceProvider
 *
 * @package WPStaging\Service\Backup
 */
class FileBackupServiceProvider extends AbstractServiceProvider
{
}
