<?php

namespace WPStaging\Framework\Adapter\Database;

abstract class AbstractDatabase implements DatabaseAdapterInterface
{

}
