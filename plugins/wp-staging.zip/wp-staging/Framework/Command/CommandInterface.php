<?php

namespace WPStaging\Framework\Command;

interface CommandInterface
{
    /**
     * @return void
     */
    public function execute();
}
