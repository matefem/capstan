<?php

namespace WPStaging\Framework\Exceptions;

use Exception;

class WPStagingException extends Exception
{

}
